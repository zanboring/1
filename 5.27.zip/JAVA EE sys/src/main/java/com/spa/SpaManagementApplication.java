package com.spa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpaManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpaManagementApplication.class, args);
    }
}