package com.spa.entity;

public enum UserRole {
    LOBBY_MANAGER,    // 大堂经理
    DEPARTMENT_MANAGER, // 部门经理
    TECHNICIAN,       // 技工
    STAFF            // 普通员工
} 