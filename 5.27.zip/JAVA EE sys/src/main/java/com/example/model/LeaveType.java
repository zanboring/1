package com.example.model;

public enum LeaveType {
    SICK_LEAVE,
    ANNUAL_LEAVE,
    PERSONAL_LEAVE,
    OTHER
} 