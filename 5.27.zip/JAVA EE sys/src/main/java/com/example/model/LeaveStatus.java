package com.example.model;

public enum LeaveStatus {
    PENDING,
    APPROVED,
    REJECTED
} 