package com.example.model;

public enum UserRole {
    LOBBY_MANAGER,
    DEPARTMENT_MANAGER,
    EMPLOYEE
} 